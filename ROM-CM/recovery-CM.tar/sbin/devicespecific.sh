#!/sbin/sh

# device specific commands to run on postrecoveryboot
